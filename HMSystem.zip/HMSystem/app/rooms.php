<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class rooms extends Model
{
    protected $table ='rooms';

    public function persons()
    {
        return $this->belongsTo('App\persons');
    }

}

