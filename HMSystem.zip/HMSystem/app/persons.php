<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class persons extends Model
{
    protected $table ='persons';
}
