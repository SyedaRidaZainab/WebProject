<?php

namespace App\Http\Controllers;

use App\Admin;
use App\persons;
use App\rooms;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\View\View;

class AdminController extends Controller
{
    public function admin()
    {
        return View('admin.cLogin');

    }

    public function login(Request $request)
    {
        $this->validate($request, [
            'username' => 'required|exists:admin',
            'password' => 'required|exists:admin',
        ]);

        $admin = Admin::where([
            'username' => $request->username,
            'password' => $request->password,
        ])->first();
        $admin_data = array(
            'admin_id' => $admin->id,
            'admin_username' => $admin->username,
        );

        Session::put($admin_data);
        
        $rooms=rooms::get();
        if(Session::has('admin_id')){
            return view('admin.index')->with(['room'=>$rooms]);
        }else{
            return redirect('/login');

        }



    }

    public function Index()
    {
        $rooms=rooms::get();
        if(Session::has('admin_id')){
            return view('admin.index')->with(['room'=>$rooms]);

        }else{
            return redirect('/login');

        }

    }


    public function Logout()
    {
        Session::flush();

        return redirect('/login');
    }

    public function addPerson(Request $request)
    {
        $newPerson = new persons();

        $newPerson->name = $request->pname;
        $newPerson->age = $request->page;
        $newPerson->number = $request->pnumber;
        $newPerson->roomId = $request->proomId;
        $newPerson->institute = $request->pins;
        $newPerson->address = $request->paddress;


        $newPerson->save();
        return redirect('/index');
    }
    public function addRoom(Request $request)
    {
        $newRoom= new rooms();
        $newRoom->room_type=$request->rtype;
        $newRoom->capacity=$request->rcap;
        $newRoom->status=$request->rstatus;

        $newRoom->save();
        return redirect('/index');


    }
    public function addRoomPage()
    {

        if(Session::has('admin_id')){

            return view('admin.addRoom');
        }else{
            return redirect('/login');

        }

    }

    public function viewPersons()
    {
        $persons=persons::paginate(4);

        if(Session::has('admin_id')){

            return view('admin.persons')->with(['person'=>$persons]);
        }else{
            return redirect('/login');

        }


    }


    public function personDelete(Request $request)
    {
        $obj=persons::find($request->id);
        $obj->delete();

        return redirect('/person_list');
    }

    public function viewRooms()
    {
        $rooms=rooms::paginate(4);

        if(Session::has('admin_id')){

            return view('admin.rooms')->with(['room'=>$rooms]);
        }else{
            return redirect('/login');

        }


    }

}
