@extends('admin.adminmaster')
@section('content')
    <div class="breadcrumb-container">
        <div class="container-fluid limited">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">

                    <li class="breadcrumb-item active" aria-current="page">Admin/Add Person</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="container-fluid limited mb-5">
        <div class="row">
            <div class="col-lg-3 col-md-4 mb-4 mb-md-0">
                <div class="card user-card">
                    <div class="card-body p-2 mb-3 mb-md-0 mb-xl-3">
                        <div class="media">
                            <img class="rounded-circle" src="{{URL::asset('img/user.png')}}" alt="admin-user">
                            <div class="media-body">
                                <h5 class="user-name">Dash Board</h5>
                                <small class="card-text text-muted">Joined Oct 30, 2018</small>
                                <div class="card-text small text-muted">Admin User</div>
                            </div>
                        </div>
                    </div>
                    <div class="list-group list-group-flush">
                        <a href="{{route('/index')}}" class="list-group-item list-group-item-action active"><i class="material-icons">person_add
                            </i> Add Persons</a>
                        <a href="{{route('/add-Room')}}" class="list-group-item list-group-item-action"><i class="material-icons">hotel
                            </i> Add Room</a>
                        <a href="{{route('/person_list')}}" class="list-group-item list-group-item-action"><i class="material-icons">person_pin</i> View Persons</a>
                        <a href="{{route('/rooms_list')}}" class="list-group-item list-group-item-action"><i class="material-icons">hotel</i> View Rooms</a>
                        <a href="{{route('/logout')}}" class="list-group-item list-group-item-action d-none d-md-block"><i class="material-icons">exit_to_app</i> Logout</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-9 col-md-8 col-sm-12">
                <div class="title"><span>Add Person Info</span></div>
                <form method="post" action="{{URL::asset('/addPerson')}}" enctype="multipart/form-data">
                    {{csrf_field()}}
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="InputTitle">Person Name</label>
                            <input type="text" name="pname" class="form-control" id="InputName" placeholder="">
                        </div>
                        <div class="form-group col-md-3">
                            <label for="Product Price">Age</label>
                            <input type="number" name="page" class="form-control"  placeholder="">
                        </div>
                        <div class="form-group col-md-3">
                            <label for="Product Price">Number</label>
                            <input type="number" name="pnumber" class="form-control"  placeholder="">
                        </div>
                        <div class="form-group col-md-6">
                        <label class="d-block">Room Allotment</label>
                        <select class="custom-select col-12" name="proomId" data-width="70px">
                            @foreach($room as $rooms)
                            <option value="{{$rooms->id}}">{{$rooms->id}}</option>
                                @endforeach
                        </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label class="d-block">Institute</label>
                            <input type="text" name="pins" class="form-control"  placeholder="">
                        </div>
                        <div class="form-group col-md-6">
                            <label class="d-block">Address</label>
                            <input type="text" name="paddress" class="form-control"  placeholder="">
                        </div>
                    </div>
                    <hr class="mt-0 mb-3">
                    <button type="submit" class="btn btn-theme my-1"><i class="material-icons">save</i> Add Person</button>
                </form>

            </div>
        </div>
    </div>
@endsection