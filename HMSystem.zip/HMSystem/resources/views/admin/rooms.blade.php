@extends('admin.adminmaster')
@section('content')
    <style type="text/css">
        a:active {
            background-color: yellow;
        }
    </style>
    <div class="breadcrumb-container">
        <div class="container-fluid limited">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">

                    <li class="breadcrumb-item active" aria-current="page">Admin/Rooms</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="container-fluid limited mb-5">
        <div class="row">
            <div class="col-lg-3 col-md-4 mb-4 mb-md-0">
                <div class="card user-card">
                    <div class="card-body p-2 mb-3 mb-md-0 mb-xl-3">
                        <div class="media">
                            <img class="rounded-circle" src="{{URL::asset('img/user.png')}}" alt="admin-user">
                            <div class="media-body">
                                <h5 class="user-name">Dash Board</h5>
                                <small class="card-text text-muted">Joined Oct 30, 2018</small>
                                <div class="card-text small text-muted">Admin User</div>
                            </div>
                        </div>
                    </div>

                    <div class="list-group list-group-flush">
                        <a href="{{route('/index')}}" class="list-group-item list-group-item-action active"><i class="material-icons">person_add
                            </i> Add Persons</a>
                        <a href="{{route('/add-Room')}}" class="list-group-item list-group-item-action"><i class="material-icons">hotel
                            </i> Add Room</a>
                        <a href="{{route('/person_list')}}" class="list-group-item list-group-item-action"><i class="material-icons">person_pin</i> View Persons</a>
                        <a href="{{route('/rooms_list')}}" class="list-group-item list-group-item-action"><i class="material-icons">hotel</i> View Rooms</a>
                        <a href="{{route('/logout')}}" class="list-group-item list-group-item-action d-none d-md-block"><i class="material-icons">exit_to_app</i> Logout</a>
                    </div>
                </div>
            </div>



            <div class="col-lg-9 col-md-8 col-sm-12">
                <div class="title"><span>All Rooms Data</span></div>
                <div class="row mb-3 border pt-2 px-3 rounded no-gutters">

                </div>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="thead-light">
                        <tr>
                            <th scope="col">Room ID</th>
                            <th scope="col">Room Type</th>
                            <th scope="col">Capacity</th>
                            <th scope="col">Status</th>
                            
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($room as $rooms)
                            <tr>
                                <td>{{$rooms->id}}</td>
                                <td>{{$rooms->room_type}}</td>
                                <td>{{$rooms->capacity}}</td>
                                <td>{{$rooms->status}}</td>

                            </tr>

                        @endforeach

                        </tbody>
                    </table>
                </div>
                {{-- <button class="btn btn-sm btn-outline-theme"><i class="material-icons">file_download</i> Export to xls</button>--}}
                <nav aria-label="Product Listing Page" class="d-flex justify-content-center mt-3">
                    <ul class="pagination">
                        {{$room->links("pagination::bootstrap-4")}}
                    </ul>
                </nav>
            </div>

        </div>
    </div>


@endsection