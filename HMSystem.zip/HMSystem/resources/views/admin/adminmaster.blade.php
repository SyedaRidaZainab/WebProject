<!DOCTYPE html>
<html lang="en">

<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">


    <title>HMS</title>

    <!-- Required css -->

    <link rel="stylesheet" href="{{URL::asset('/bootstrap/css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <!-- Plugins css -->
    <link rel="stylesheet" href="{{URL::asset('/css/swiper.min.css')}}">

    <!-- Template css -->
    <link rel="stylesheet" href="{{URL::asset('/css/style.min.css')}}">






</head>
<body>




<div class="middle-header" id="middle-header">
    <div class="container-fluid limited position-relative">


        <div class="row">

            <div class="col-4 d-flex d-md-none align-items-center">
                <a href="#" class="text-dark" data-toggle="modal" data-target="#menuModal"><i class="material-icons md-2">menu</i></a>
            </div>
            <div class="col-4 col-md-auto d-flex align-items-center justify-content-center justify-content-md-start">
                <a href="{{URL::asset('/admin/index')}}" class="logo">
                    <img src="{{URL::asset('/img/logo.png')}}" alt="HMS" class="d-none d-md-block">
                    <img src="{{URL::asset('/img/logo.png')}}" alt="HMS" class="d-block d-md-none">
                </a>
            </div>


        </div>
    </div>
</div>


<!-- Modal Menu -->
<div class="modal fade modal-menu" id="menuModal" tabindex="-1" role="dialog" aria-labelledby="menuModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="menuModalLabel">
                    <a href="{{URL::asset('/')}}" class="d-inline-block"><img src="{{('/img/LOGO.png')}}" alt="Cottonwood" height="35"></a>
                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    </div>
</div>
@yield('content')




<!-- Copyright -->
<div class="copyright">
    Copyright © 2018 HMS All right reserved
</div>
<!-- /Copyright -->

<a href="#top" class="back-top text-center" id="back-top">
    <i class="material-icons">expand_less</i>
</a>
<!-- Required js -->
<script src="{{URL::asset('/js/jquery.min.js')}}"></script>
<script src="{{URL::asset('/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
<script src="{{URL::asset('/js/typeahead.bundle.min.js')}}"></script>

<!-- Plugins js -->
<script src="{{URL::asset('/js/swiper.min.js')}}"></script>
<script src="{{URL::asset('/js/jquery.countdown.min.js')}}"></script>

<!-- Template JS -->
<script src="{{URL::asset('/js/script.min.js')}}"></script>



<script type="text/javascript">

    $(document).ready(function(){
        $(".toggle-search").on("click",function(){
            $(".input-search-wrapper").removeClass("invisible");
        });
        $("#close").on("click",function(){
            $(".input-search-wrapper").addClass("invisible");
        });
    });

</script>

</body>

</html>