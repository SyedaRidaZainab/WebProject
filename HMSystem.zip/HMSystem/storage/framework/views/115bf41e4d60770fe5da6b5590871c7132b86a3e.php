<?php $__env->startSection('content'); ?>
    <div class="breadcrumb-container">
        <div class="container-fluid limited">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">

                    <li class="breadcrumb-item active" aria-current="page">Admin/Add Person</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="container-fluid limited mb-5">
        <div class="row">
            <div class="col-lg-3 col-md-4 mb-4 mb-md-0">
                <div class="card user-card">
                    <div class="card-body p-2 mb-3 mb-md-0 mb-xl-3">
                        <div class="media">
                            <img class="rounded-circle" src="<?php echo e(URL::asset('img/user.png')); ?>" alt="admin-user">
                            <div class="media-body">
                                <h5 class="user-name">Dash Board</h5>
                                <small class="card-text text-muted">Joined Oct 30, 2018</small>
                                <div class="card-text small text-muted">Admin User</div>
                            </div>
                        </div>
                    </div>
                    <div class="list-group list-group-flush">
                        <a href="<?php echo e(route('/index')); ?>" class="list-group-item list-group-item-action active"><i class="material-icons">person_add
                            </i> Add Persons</a>
                        <a href="<?php echo e(route('/add-Room')); ?>" class="list-group-item list-group-item-action "><i class="material-icons">hotel
                            </i> Add Room</a>
                        <a href="<?php echo e(route('/person_list')); ?>" class="list-group-item list-group-item-action"><i class="material-icons">person_pin</i> View Persons</a>

                        <a href="<?php echo e(route('/rooms_list')); ?>" class="list-group-item list-group-item-action"><i class="material-icons">hotel</i> View Rooms</a>
                        <a href="<?php echo e(route('/logout')); ?>" class="list-group-item list-group-item-action d-none d-md-block"><i class="material-icons">exit_to_app</i> Logout</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-9 col-md-8 col-sm-12">
                <div class="title"><span>Add Person Info</span></div>
                <form method="post" action="<?php echo e(URL::asset('/addRoom')); ?>" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="InputTitle">Room Type</label>
                            <input type="text" name="rtype" class="form-control" id="InputName" placeholder="">
                        </div>
                        <div class="form-group col-md-3">
                            <label for="Product Price">Capacity</label>
                            <input type="number" name="rcap" class="form-control"  placeholder="">
                        </div>
                        <div class="form-group col-md-3">

                        </div>
                        <div class="form-group col-md-6">
                            <label class="d-block">Room Status</label>
                            <select class="custom-select col-12" name="rstatus" data-width="70px">
                                    <option value="1">Available</option>
                                    <option value="0">Full</option>

                            </select>
                        </div>
                    </div>
                    <hr class="mt-0 mb-3">
                    <button type="submit" class="btn btn-theme my-1"><i class="material-icons">save</i> Add Room</button>

                </form>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>