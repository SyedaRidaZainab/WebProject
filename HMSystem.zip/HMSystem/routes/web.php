<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('admin.clogin');
});


Route::get('/login','AdminController@admin');

Route::post('/my-account', 'AdminController@login');

Route::get('/index', 'AdminController@Index')->name('/index');
Route::post('/addPerson','AdminController@addPerson');
Route::post('/addRoom','AdminController@addRoom');
Route::get('/add-Room','AdminController@addRoomPage')->name('/add-Room');
Route::get('/person/delete', 'AdminController@personDelete');
Route::get('/person_list','AdminController@viewPersons')->name('/person_list');
Route::get('/rooms_list','AdminController@viewRooms')->name('/rooms_list');

Route::get('/logout', 'AdminController@Logout')->name('/logout');


